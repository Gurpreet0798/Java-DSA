package bit_manipulation;

public class binary_rightshift {
    public static void main(String[] args) {
        System.out.println(6>>1);
    }
}
