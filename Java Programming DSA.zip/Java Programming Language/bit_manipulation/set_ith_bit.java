package bit_manipulation;

public class set_ith_bit {
    public static int Set_ith_bit(int n){
        int i = 2;
        int bitmask = (1<<i);
        return n | bitmask;
    }
    public static void main(String[] args) {
        System.out.println(Set_ith_bit(10));
    }
}
