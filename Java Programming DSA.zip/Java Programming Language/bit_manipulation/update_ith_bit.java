package bit_manipulation;
public class update_ith_bit {
    public static int Clear_ith_bit(int n, int i){
        int bitmask = ~(1<<i);
        return n & bitmask;
    }
    public static int Set_ith_bit(int n, int i){
        int bitmask = (1<<i);
        return n | bitmask;
    }
    public static int Update_ith_bit(int n, int i, int newBit){
        //THERE ARE TWO ALTERNATIVE SOLUTIONS FOR THIS QUESTION:-
        //HERE THIS IS THE FIRST APPROACH FOR THIS QUESTION:-
        // if(newBit == 0){
        //     return Clear_ith_bit(n, i);
        // }else{
        //     return Set_ith_bit(n,i);
        // }
        //1. CLEAR THE BIT AND THEN SET THE BIT
        //2. USE A MASK AND THEN SET THE BIT
        //HERE WE ARE USING THE SECOND APPROACH
        n = Clear_ith_bit(n, i);
        int Bitmask = newBit << i;
        return n | Bitmask;
    }
    public static void main(String[] args) {
        System.out.println(Update_ith_bit(10, 2, 1));
    }
}
