package bit_manipulation;

public class bitwise_AND {
    public static void main(String[] args) {
        System.out.println(5 & 6);
    }
}
