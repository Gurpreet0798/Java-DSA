package bit_manipulation;

public class binary_odd_even {
    public static void oddOrEven(int n){
        int bitmask = 1;
        if((n & bitmask) == 1){
            System.out.println("odd number");
        }
        else{
         System.out.print("even ");
        }
    }

    public static void main(String[] args){
        oddOrEven(9);
    }
    
}
