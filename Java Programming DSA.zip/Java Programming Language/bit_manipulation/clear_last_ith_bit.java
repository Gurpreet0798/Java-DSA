package bit_manipulation;

public class clear_last_ith_bit {
    public static int Clear_Last_ith_bit(int n){
        // you need to treat n as an unsigned value
        int i = 2;
        int bitMask = ((-1)<<i);
        // OR WRITE IT AS (~0 << i);
        //BOTH ARE SAME AND CAN BE USED FOR THE SAME THING.
        return n & bitMask;

    }
    public static void main(String[] args) {
        System.out.println(Clear_Last_ith_bit(15));
    }
}
