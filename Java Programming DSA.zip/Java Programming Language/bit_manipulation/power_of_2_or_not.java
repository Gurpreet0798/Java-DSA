package bit_manipulation;

public class power_of_2_or_not {
    public static boolean isPowerofTwo(int n){
        return (n&(n-1)) == 0;
    }
    public static void main(String[] args) {
        System.out.println(isPowerofTwo(8));
    }
}
