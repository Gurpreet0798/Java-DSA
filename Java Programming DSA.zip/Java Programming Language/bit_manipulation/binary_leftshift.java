package bit_manipulation;

public class binary_leftshift {
    public static void main(String[] args) {
        System.out.println(5<<2);
    }    
}
