public class arithmetic {

    public static void main(String args[]){
        int A = 10;
        int B = 20;
        System.out.println("add:- " + (A+B));
        System.out.println("Sub:- " + (A-B));
        System.out.println("Mul:- " + (A*B));
        System.out.println("div:- " + (A/B));
        System.out.println("mod:- " + (A%B));


    }
    
}
