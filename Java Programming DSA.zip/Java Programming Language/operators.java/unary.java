public class unary {
    public static void main(String args[]){
        int a = 10;
        // int b = ++a; // pre-increment
        // int b = a++; // post-increment
        // int b = --a; // pre-decrement
        int b = a--; // post-decrement
        System.out.println(a);
        System.out.println(b);
    
    }
}
