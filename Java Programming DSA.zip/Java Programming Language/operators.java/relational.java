public class relational {
    public static void main(String args[]){
        int A = 10;
        // int B = 20;
         int B = 10;
        System.out.println(A != B); 

    }
}
