public class logical {
    public static void main(String args[])
    {
       // AND OPERATOR CASE
        // System.out.println((3>2) && (5>4)); // true
        // System.out.println((3>2) && (5<4)); // false
        // System.out.println((3<2) && (5>4)); // false
        // System.out.println((3<2) && (5<4)); // false
    }
}
