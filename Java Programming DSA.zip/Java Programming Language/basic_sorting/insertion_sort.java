package basic_sorting;

public class insertion_sort {
    public static void insertionSort(int arr[]){
        for(int i = 1; i<arr.length; i++){
            //TEMPERORY ELEMENT FOR STORING A VALUE FOR SOMETIME.
            int curr = arr[i];
            int prev = i-1;
            //FINDING OUT THE CORRECT POS TO INSERT THE ELEMENT BY SEARCHING FROM BACKSIDE AS WE USE TO COMPARE FROM BACK OF THE ARRAY.
            while(prev >= 0 && arr[prev] > curr){
                arr[prev+1] = arr[prev];
                prev--; //AS WE ARE COMPARING FROM BACKSIDE SO WE NEED TO DECREMENT THE PREV POINTER.
            }
            //INSERTING THE ELEMENT AT THE CORRECT POSITION.
            arr[prev+1] = curr;
        }
    }
    public static void printArr(int arr[]){
        for(int i = 0; i < arr.length; i++){
            System.out.println(arr[i] + " ");
        }
    }
    public static void main(String[] args) {
        int arr[] = {5, 4, 1, 3, 2};
        insertionSort(arr);
        printArr(arr);
    }
}
