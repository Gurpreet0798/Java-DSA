package basic_sorting;

public class counting_sort {
    public static void countingSort(int arr[]){
        int largest = Integer.MIN_VALUE;//ALWAYS TAKE REVERSE IN THE LARGEST AND SMALLEST VALUE.
        //MEANS IN LARGEST TAKE MIN VALUE AND IN SMALLEST TAKE MAX VALUE.
        for(int i = 0; i < arr.length; i++){
            largest = Math.max(largest, arr[i]);
        }

        int count[] = new int[largest+1];
        // HERE THIS [largest+1] IS USED BECAUSE WE NEED TO STORE THE COUNT OF THE LARGEST ELEMENT OR WE CAN ALSO CALLED IT RANGE FOR COUNTING SORT ALSO AND TO SPECIFY THE CORRECT RANGE FOR THE GIVEN ARRAY WE USE [largest+1].
        for(int i = 0; i<arr.length; i++){
            count[arr[i]]++;//HERE WE NEED TO ITERATE ON THE ORIGINAL ARRAY AND STORE THE COUNT OF THE ELEMENTS IN THE COUNT ARRAY.
        }
        // NOW WE NEED TO STORE THE COUNT OF THE ELEMENTS IN THE COUNT ARRAY BASICALLY THE COUNTING SORT OR SORTING CODE:-
        int j = 0;
        for(int i = 0; i<count.length; i++){
            //HERE WE NEED TO ITERATE ON THE COUNT ARRAY BECAUSE NOW WE ARE WORKING ON THE COUNT ARRAY.
            while(count[i] > 0){
                arr[j] = i;
                j++;
                count[i]--;
            }
        }
    }
    public static void printArr(int arr[]){
        for(int i = 0; i < arr.length; i++){
            System.out.print(arr[i] + " ");
        }
    }
    public static void main(String[] args) {
        int arr[] = {1, 4, 1, 3, 2, 4, 3, 7};
        countingSort(arr);
        printArr(arr);
    }
}
//WHEN WE HAVE NEGATIVE NUMBERS IN OUR ARRAY THEN THE BEST WAY TO SORT IT IS THAT SORT IT BY FIRST CHANGING ALL THE NUMBERS TO POSITIVE AND THEN SORT IT AND THEN AGAIN CHANGE IT TO NEGATIVE BY JUST ADDING A -VE SIGN TO IT.
//FOR EXAMPLE:-
// int arr[] = {1, -4, 1, -3, 2, 4, 3, -7};
// int largest = Integer.MIN_VALUE;
// int smallest = Integer.MAX_VALUE;
// for(int i = 0; i < arr.length; i++){
//     largest = Math.max(largest, arr[i]);
//     smallest = Math.min(smallest, arr[i]);
// }
// int count[] = new int[largest-smallest+1];
// for(int i = 0; i<arr.length; i++){
//     count[arr[i]-smallest]++;
// }
// int j = 0;
// for(int i = 0; i<count.length; i++){
//     while(count[i] > 0){
//         arr[j] = i + smallest;
//         j++;
//         count[i]--;
//     }
