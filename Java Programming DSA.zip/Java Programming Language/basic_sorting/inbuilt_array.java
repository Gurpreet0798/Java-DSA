package basic_sorting;
import java.util.*;

public class inbuilt_array {
    // CHANGE int TOO Integer for using Collections.reverseOrder() method TO CHANGE THE ARRAY IN DECREASING ORDER.
    public static void printArr(Integer arr[]){
        for(Integer i = 0; i < arr.length; i++){
            System.out.print(arr[i] + " ");
        }
    }
    public static void main(String[] args) {
        Integer arr[] = {5, 4, 1, 3, 2};
        // Arrays.sort(arr);
        // Arrays.sort(arr, 0 , 4); 
        //sorts from index 1 to 3
        
        // FOR SORTING IN REVERSE ORDER:-
        Arrays.sort(arr, Collections.reverseOrder());
        // SORTING IN REVERSE ORDER FROM INDEX 0 TO 3.
        Arrays.sort(arr, 0, 4, Collections.reverseOrder());


        printArr(arr);
    }
}
