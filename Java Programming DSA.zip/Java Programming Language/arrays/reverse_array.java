package arrays;

public class reverse_array {
    public static void reverse(int numbers[]){
        int start = 0;
        int last = numbers.length - 1;
        while(start < last){
            //basic swapping code:-
            int temp = numbers[start];
            numbers[start] = numbers[last];
            numbers[last] = temp;

            start++;
            last--;

        }
    }


    public static void main(String[] args) {
        int numbers[] = {2, 4, 6, 8, 10};

        reverse(numbers);//calling the reverse function.

        for(int i = 0; i < numbers.length; i++){
            System.out.print(numbers[i] + " ");
        }   
    }
}
 