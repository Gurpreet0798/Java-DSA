package arrays;

public class trapping_rainwater {
    public static int trappedRainwater(int height[]){
        // CALCULATE LEFT MAX BOUNDRY --> AUXILARY ARRAY.
        int leftMax[] = new int[height.length];
        leftMax[0] = height[0];//WE ARE CALCULATING IT FROM THE FRONT SIDE OR FROM THE LEFT SIDE.
        for(int i = 1; i<height.length; i++){
            leftMax[i] = Math.max(height[i], leftMax[i-1]);
        }

        // CALCULATE RIGHT MAX BOUNDRY --> AUXILARY ARRAY.
        int rightMax[] = new int[height.length];
        rightMax[height.length-1] = height[height.length-1];//WE ARE CALCULATING IT FROM THE BACK SIDE OR FROM THE RIGHT SIDE.
        for(int i = height.length-2; i>=0; i--){
            rightMax[i] = Math.max(height[i], rightMax[i+1]);//TO CALCULATE FROM THE RIGHT SIDE, WE ARE TRAVERSING FROM THE BACK SIDE.
        }

        //LOOP
        int trappedWater = 0;
        for(int i = 0; i<height.length; i++){
            //WATERLEVEL = MIN(LEFTMAX BOUND, RIGHTMAX BOUND)
            int waterLevel = Math.min(leftMax[i], rightMax[i]);
            //TRAPPED WATER = WATERLEVEL - HEIGHT[i]
            trappedWater += waterLevel - height[i];
        }
        return trappedWater;
    }
    public static void main(String[] args) {
        int height[] = {4, 2, 0, 6, 3, 2, 5};
        System.out.println("The amount of water trapped is: " +trappedRainwater(height));
    }
}
