package arrays;

public class binary_search {
    public static int binarySearch(int numbers[], int key){
        int start = 0;
        int end = numbers.length - 1;
        while(start <= end){
            int mid = (start + end)/2;
            if(numbers[mid] == key){//mid == key.
                return mid;
            }
            if(numbers[mid] < key){//right side of the array.
                start = mid + 1;
            }
            else{//left side of the array.
                end = mid - 1;
            }
        }
        return -1;
    }




    public static void main(String[] args) {
        int numbers[] = {2, 4, 6, 8, 10, 12, 14};
        int key = 99;
        //here it is used to return the index value of the key. 
        System.out.println(binarySearch(numbers,key));
    }
}
