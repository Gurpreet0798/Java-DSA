package arrays;

public class arguments_arrays {
    public static void update(int marks[], int nonchangeable){
        nonchangeable = 98;
        for(int i = 0; i < marks.length; i++){
            marks[i] = marks[i] + 1;//HERE marks.length is the index of the array + 1
        }
    }
    public static void main(String[] args){
        int marks[] = {10, 20, 30, 40};

        int nonchangeable = 45;

        
        update(marks , nonchangeable);
        System.out.println(nonchangeable);
        for(int i = 0; i < marks.length; i++){
            System.out.print(marks[i] + " ");
        }
        System.out.println(" ");
    }
}


