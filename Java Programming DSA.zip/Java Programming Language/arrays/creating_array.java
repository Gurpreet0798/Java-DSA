package arrays;

public class creating_array {
    public static void main(String[] args) {
        // int number[] = new int[5];
        // number[0] = 10;
        // number[1] = 20;
        // number[2] = 30;
        // System.out.println(number[2]);

        // Another way to create an array:-
        // int number[] = {10, 20, 30, 40, 50};
        // System.out.println(number[3]);

        // Another way to create an array:-
        String Fruit[] = {"Apple", "Banana", "Orange", "Mango"};
        System.out.println(Fruit[3]);
    }
}


