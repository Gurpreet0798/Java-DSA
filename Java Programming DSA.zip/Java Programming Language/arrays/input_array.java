package arrays;
import java.util.*;

public class input_array {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        int marks[] = new int[49];

        //LENGTH OF AN ARRAY:- 
        System.out.println("length of an array:- " +marks.length);
        //our array was made by the name marks so we have to use that variable name to find the length of an array.

        //INPUTTING AN ARRAY:-

        // int marks[] = {10, 20, 30, 40, 50};
        // marks[0] = sc.nextInt();
        // marks[1] = sc.nextInt();
        // marks[2] = sc.nextInt();
        // System.out.println("physics : " +marks[0]);
        // System.out.println("chemistry : " +marks[1]);
        // // System.out.println("maths : " +marks[2]);
        // marks[2] = 100;
        // // marks[2] = marks[2] + 1;
        // System.out.println("maths : " +marks[2]);
        // int avg = ((marks[0] + marks[1] + marks[2])/3);
        // System.out.println("Average : " +avg);
        sc.close();
    }
}
