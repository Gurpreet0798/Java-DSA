package arrays;


public class subarrays {
    public static void printSubarrays(int numbers[]){
        int total = 0;
        //HERE i IS REFERED TO AS THE STARTING INDEX AND j IS REFERED TO AS THE ENDING INDEX. i IS THE INDEX OF THE ARRAY SO ALWAYS TAKE REFERENCE FROM THE INDEX OF THE ARRAY FOR SOLVING THIS TYPE OF Array questions.
        for(int i = 0; i< numbers.length; i++){
            int start = i;
            for(int j = i; j<numbers.length; j++){
                int end = j;
                for(int k = start; k<=end; k++){
                    System.out.print(numbers[k] + " ");
                }
                total++;
                System.out.println(" ");
            }
            System.out.println(" ");
        }
        System.out.println("Total subarrays are: " +total);
    }
    





    public static void main(String[] args) {
        int numbers[] = {2, 4, 6, 8, 10};
        printSubarrays(numbers);
    }
}
