public class whileloop {
    public static void main(String args[]){
        int i = 0;
        while(i<100){
            System.out.println("Hello World");
            i++;// FOR INCREASING IT WE USE INCREASING OPERATOR.
        }
    }
    
}
