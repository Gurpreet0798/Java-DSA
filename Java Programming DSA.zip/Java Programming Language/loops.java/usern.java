import java.util.*;
public class usern {
    public static void main(String args[]){
        Scanner sc = new Scanner(System.in);
        System.out.println("Enter the number: ");
        int n = sc.nextInt();
        sc.close();
        int i=1;
        while(i<=n){
            System.out.println(i);
            i++;
         }   
     }
}
