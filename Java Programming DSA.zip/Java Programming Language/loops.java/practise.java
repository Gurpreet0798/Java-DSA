//QUESTION-----1......
//HELLO IS PRINTED 2 TIMES BECAUSE INITIAL IS FROM 0 AND FINAL WILL BE TILL 4 AS(i<5) AND INCREMENT IS 2 SO IT WILL PRINT 0,2,4 AND 4 IS LESS THAN 5 SO IT WILL PRINT HELLO 2 TIMES.


//QUESTION-----2......
// import java.util.*;
// public class practise {
//     public static void main(String args[]){
//         Scanner sc = new Scanner(System.in);
//         System.out.println("Enter the integers:- ");
//         int n = sc.nextInt();
//         sc.close();
//         int sum = 0;
//         int evensum = 0;
//         int oddsum = 0;
//         for(int i = 1; i<=n; i++){
//             if(n%2==0){
//                 evensum = sum + i;
//             }
//             else{
//                 oddsum = sum + i;
//             }
//             System.out.println("The sum of even numbers is: "+evensum);
//             System.out.println("The sum of odd numbers is: "+oddsum);
//         }
//     }
// }

//QUESTION-----3......

import java.util.*;
public class practise{
    public static void main(String args[]){
        Scanner sc = new Scanner(System.in);
        System.out.println("Enter the number whose factorial must be found: ");
        sc.close();
        
    }
}
