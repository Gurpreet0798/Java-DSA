import java.util.*;
public class sum {
    public static void main(String args[]){
        Scanner sc = new Scanner(System.in);
        System.out.println("Enter the number: ");
        int n = sc.nextInt();
        sc.close();
        int sum = 0;
        //INITIALIZATION, CONDITION, INCREMENT/DECREMENT
        //INTILIZING SUM AT THE STARTING IS 0.
        int i = 1;
        while(i<=n){
            sum = sum + i;
            i++;
        }
        System.out.println(sum);

    }
    
}
