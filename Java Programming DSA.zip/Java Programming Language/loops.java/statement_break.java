public class statement_break {
    public static void main(String args[]){
        int n = 3;
        for(int i = 1; i<=5; i++){
            System.out.println(i);
            if(i==n){
               break;
            }
          }
        // for(int i = 1; i<=10; i++){
        //     System.out.println(i);
        //     if(i==3){
        //         break;
        //     }
        // }
    }
}
