public class reverse {
    public static void main(String args[]){
        int n = 10899;
        while(n>0){
            int last_digit = n%10;//FOR GETTING THE LAST DIGIT OF THE NUMBER
            System.out.print(last_digit);
            n = n/10;//FOR REMOVING THE LAST DIGIT FROM THE GIVEN NUMBER.
        }
     
    }
   }
    

