import java.util.*;
public class question_continue {
    public static void main(String args[]){
        Scanner sc = new Scanner(System.in);
        System.out.println("Enter the number: ");
        int n = sc.nextInt();
        sc.close();
        while(n>0){
            System.out.println(n);
            if(n%9==0){
                System.out.println("Divisible by 9");
                continue;
            }
            else{
                break;
            }
        }
    }
}
