import java.util.*;
public class primenumber {
    public static void main(String args[]){
        Scanner sc = new Scanner(System.in);
        System.out.println("Enter the number: ");
        int n = sc.nextInt();
        sc.close();
        int counter = 0;
        for(int i = 1;i<=n; i++){
            if(n%i==0){
                counter++;
            }
        }
        if(counter==2){
            System.out.println("Prime");
        }
        else{
            System.out.println("Not Prime");
        }
    }
}
//THIS QUESTION CAN ALSO BE DONE IN THE FORM OF BOOLEAN TRUE OR FALSE.
// TRY TO PRACTISE THIS QUESTION IN BOOLEAN FORM.   
// IN BOOLEAN FORM IT WILL BE:-
//AFTER TAKING INPUT FOR n FROM UPSIDE USE THIS CODE AND ITS LOGIC:-





// if(n==2)
// {
//     System.out.println("n is prime");
// }
// else{
//     boolean isprime = true;
//     for(int i = 2; i<=Math.sqrt(n); i++){
//         if(n%i==0){
//             isprime = false;
//             break;
//         }
//     }
//     if(isprime==true){
//         System.out.println("n is prime");
//     }
//     else{
//         System.out.println("n is not prime");
//     }
// }