public class inverted_halfpyramidwithnumbers {
    public static void inverted_halfpyramid_withnumbers(int n){
        for(int i = 1; i<= n; i++){
            for(int j = 1; j<= n-i+1; j++){
                System.out.print(j);
            }
            System.out.println(" ");
        }
    }
    public static void main(String[] args) {
        inverted_halfpyramid_withnumbers(5);
    }
}