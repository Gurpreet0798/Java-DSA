import java.util.*;
public class sum {
    public static void main(String args[]){
        Scanner sc = new Scanner(System.in);
        int number1 = sc.nextInt();
        System.out.println("Enter the first number:" +number1);
        int number2 = sc.nextInt();
        System.out.println("Enter the second number: " +number2);
        sc.close();
        int sum = number1 + number2;
        System.out.println("Sum of two numbers is: " +sum);
    }
    
}
