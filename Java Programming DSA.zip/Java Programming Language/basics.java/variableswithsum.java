public class variableswithsum {
    public static void main(String args[]){
        int a , b , sum;
        a=10;
        b=20;
        sum=a+b;

        System.out.println("sum of a and b is: "+sum);
        }
    
}
