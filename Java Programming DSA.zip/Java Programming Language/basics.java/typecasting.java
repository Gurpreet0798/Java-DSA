public class typecasting {
    public static void main(String args[]){
        //float a = 10.5f;
        //int b = a; THIS WILL CREATE A PROBLEM IN CONVERSION BECAUSE IT IS NOT FOLLOWING THE RULES OF TYPECASTING
        // SO INSTED OF THIS WE WILL USE TYPECASTING AS FOLLOWS:
        //int b = (int)a;
        // IT IS EVEN USED IN THE CASE OF CHARACTERS AS WELL FOR CHANGING IT INTO THE INTEGER VALue
       char ch = 'a';
       int b = ch;
         System.out.println("new value of b: " +b);

    }
}
