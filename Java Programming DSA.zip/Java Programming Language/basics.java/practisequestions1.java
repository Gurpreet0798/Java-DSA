//Question 1:-
// import java.util.*;
//     public class practisequestions1{
//         public static void main(String args[]){
//             Scanner sc = new Scanner(System.in);
//             int A = sc.nextInt();
//             System.out.println("First number A: "+A);
//             int B = sc.nextInt();
//             System.out.println("First number A: "+B);
//             int C = sc.nextInt();
//             System.out.println("First number A: "+C);
//             sc.close();
//             int average = (A+B+C)/3;
//             System.out.println("Average of three numbers A, B and C is:" +average);
//         }
//     }

//Question 2:-
// import java.util.*;
// public class practisequestions1{
//     public static void main(String args[]){
//         Scanner sc = new Scanner(System.in);
//         int side = sc.nextInt();
//         System.out.println("Enter the side of the square: " +side);
//         sc.close();
//         int area = side * side;
//         System.out.println("Area of the square is: " +area);
//     }
// }
   
//Question 3:-
import java.util.*;
public class practisequestions1{
    public static void main(String args[]){
        Scanner sc = new Scanner(System.in);
        float pencil = sc.nextFloat();
        System.out.println("Enter the price of the pencil: " +pencil);
        float pen = sc.nextFloat();
        System.out.println("Enter the price of the pen: " +pen);
        float eraser = sc.nextFloat();
        System.out.println("Enter the price of the eraser: " +eraser);
        sc.close();
        float total = pencil + pen + eraser;
        System.out.println("Total price of the pencil, pen and eraser is: " +total);
        float gst = total * 0.18f;
        System.out.println("GST on the total price is: " +gst);

    }
}

