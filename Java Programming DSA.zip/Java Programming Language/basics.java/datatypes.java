public class datatypes {
    public static void main(String args[]){
        int a = 10;
        float b = 10.5f;
        double c = 10.5;
        char d = 'A';
        String e = "Hello World";
        boolean f = true;
        byte g = 127;
        System.out.println(a);
        System.out.println(b);
        System.out.println(c);
        System.out.println(d);
        System.out.println(e);
        System.out.println(f);
        System.out.println(g);



    }
    
}
