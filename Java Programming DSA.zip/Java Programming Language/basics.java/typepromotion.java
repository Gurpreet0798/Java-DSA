public class typepromotion {
    public static void main(String args[]){
        // Based on rule no. 1 of the type promotions, the smaller data type is promoted to the larger data type.
        // char a = 'a';
        // char b = 'b';
        // //System.out.println(a); //simple character is printed here. to convert it into integer, we need to use type promotion as follows:
        // System.out.println((int) b);
        // System.out.println((int) a);
        // System.out.println(b-a);

        // Now based on the rule no.2:-
        int a = 10;
        float b = 20.25f;
        long c = 25;
        double d = 30;
        double ans = a+b+c+d;
        System.out.println(ans);
    }
    
}
