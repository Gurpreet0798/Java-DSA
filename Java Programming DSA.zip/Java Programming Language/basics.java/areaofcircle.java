import java.util.*;
public class areaofcircle {
    public static void main(String args[]){
        Scanner sc = new Scanner(System.in);
        float radius = sc.nextFloat();
        System.out.println("Enter the radius of the circle: " +radius);
        sc.close();
        float pi = 3.14f;
        // IN JAVA, it does not accept the float value without f at the end of the number as it considers every value as double by default.
        // So to make the value accepted as float value we need to describe it as float value by adding f at the end of the number e.g:- 3.14f.
        float area = pi * radius * radius;
        System.out.println("Area of the circle is: " +area);
        



       
    
    }
    
}
