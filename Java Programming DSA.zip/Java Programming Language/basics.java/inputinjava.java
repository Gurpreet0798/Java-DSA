import java.util.*;
public class inputinjava{
    public static void main(String args[]){
        Scanner sc = new Scanner(System.in);
        // String input = sc.next();
        //when you want to store more inputs in a single line after a space then use nextLine() method.
        // String input = sc.nextLine();
        //  System.out.println("Input entered by me:" + input);
        // when you want to take the input in the Integer format then use nextInt() method.
        // int number= sc.nextInt();
        // System.out.println("Input number: " +number);
        // when you want to take the input in the float form then use nextFloat() method.
        float number = sc.nextFloat();
        sc.close();
        // IN JAVA, WHEN YOU ARE USING INPUT METHOD ANS YOU ARE USING sc IN ITS FORMAT MAKE SURE TO CLOSE IT.
        // IN JAVA, WHEN WE ARE USING sc TO TAKE INPUT THEN IT ALWAYS STAYS ACTIVE SO WE NEED TO CLOSE IT BY PUTTING sc.close()
        // AT THE END OF THE PROGRAM.
        System.out.println("Input number: " +number);

       
    }
}