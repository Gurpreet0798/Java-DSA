import java.util.*;

public class typeconversion {
    public static void main(String args[]){
        Scanner sc = new Scanner(System.in);
         int a = sc.nextInt();
         System.out.println("Enter the first number: " +a);
         sc.close();
         long b = a;

        // long a = sc.nextLong();
        // System.out.println("Enter the first number: " +a);
        // sc.close();
        // int b = a;
        //In java, we can not assign a value of a larger data type to a smaller data type.
        // here in this case int is small while long is large so we can not assign the value of long to int.
        //however in first case we can assign the value of int to long as int is small while long is large.







        //  int a = 10;
        //  long b = a;

        // long a = 10;
        // int b = a;
        System.out.println("new value of b: " +b);
    }
    
}
