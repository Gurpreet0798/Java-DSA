public class javabasics{
    public static void main(String args []){
        System.out.print("Hello World\n"); // println is used to print the statement in the next line...
        System.out.print("Hello World\n");
        System.out.print("Hello World\n");
       

    }
}

// The code which we are always going to write at the starting of a java program is called a boiler-plate code.