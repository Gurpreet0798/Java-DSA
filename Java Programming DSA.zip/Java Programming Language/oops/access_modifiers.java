package oops;

public class access_modifiers {
    public static void main(String[] args) {
     BankAccount myAcc = new BankAccount();
     myAcc.username = "Gurpreet";
     //myAcc.password = "abcdefghij";//HERE OUR PASSWORD IS PRIVATE SO ITS VISIBILITY IS CANCELLED;
    }
}

class BankAccount{
    public String username;
    //private String password;
    public void setPassword(String pwd){
        // password = pwd;
    }
}
