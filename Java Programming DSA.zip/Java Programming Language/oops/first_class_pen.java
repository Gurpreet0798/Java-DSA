package oops;

public class first_class_pen {
    public static void main(String[] args) {
        Pen p1 = new Pen();//THIS IS A CONSTRUCTOR.
        //HERE WE WILL CREATE A PEN OBJECT CALLED p1.
        p1.setColor("BLUE");
        System.out.println(p1.color);
        p1.setTip(5);
        System.out.println(p1.tip);
        p1.color = "YELLOW";
        System.out.println(p1.color);
    }
}

class Pen{//THIS IS A CLASS AND IT IS FORMED LIKE THIS BY JUST WRITING CLASS KEYWORD IN THE STARTING

// HERE ALL THE PROPERTIES AND THE FUNCTIONS OF THE PEN ARE DEFINED IN THIS PARENTHESIS BLOCK...

//PEN MUST HAVE THESE QUALITIES...
    String color;
    int tip;
//PEN MUST HAVE THESE FUNCTIONS...
    void setColor(String newColor){
        color = newColor;
    }

    void setTip(int newTip){
        tip = newTip;
    }
}

// class Student{
//     String name;
//     int age;
//     float percentage;

//     void calcPercentage(int phy, int chem, int math){
//         percentage = (phy + chem + math) / 3.0f;
//     }
// }