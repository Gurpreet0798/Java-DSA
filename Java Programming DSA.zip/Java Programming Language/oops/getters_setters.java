package oops;

public class getters_setters {
    public static void main(String[] args) {
        Pen p1 = new Pen();//THIS IS A CONSTRUCTOR.
        //HERE WE WILL CREATE A PEN OBJECT CALLED p1.
        p1.setColor("BLUE");
        System.out.println(p1.getColor());
        p1.setTip(5);
        System.out.println(p1.getTip());
        p1.setColor("YELLOW");
        System.out.println(p1.getColor());
    }
}

class Pen{
    private String color;
    private  int tip;
//USE OF GETTERS:-
    String getColor(){
        return this.color;
    }
    int getTip(){
        return this.tip;
    }
//USE OF SETTERS:-
    void setColor(String newColor){
        this.color = newColor;
    }
    void setTip(int newTip){
        this.tip = newTip;
    }
}

