package oops;

public class constructor_types {
    public static void main(String[] args) {
        Student s1 = new Student();
        Student s2 = new Student("Gurpreet");
        Student s3 = new Student(123);
    }
}

class Student{
    String name;
    int roll;

    Student(){//THIS IS NON-PARAMETERISED CONSTRUCTOR...
        System.out.println("Constructor called when object is created.");
    }
    Student(String name){//THESE ARE THE PARAMETERISED CONSTRUCTOR IN WHICH A PARAMETER IS TAKEN.
    //THE PARAMETER CAN BE EITHER NAME OR ROLL BUT HERE IN THIS CASE A PARAMETER ALWAYS LIES...
        this.name = name;
    }
    Student(int roll){//THIS IS ALSO PARAMETERISED CONSTRUCTOR...
        this.roll = roll;
    }
}
