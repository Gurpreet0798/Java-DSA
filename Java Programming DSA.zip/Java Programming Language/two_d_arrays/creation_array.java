package two_d_arrays;
import java.util.*;

public class creation_array {
    //CODE IF WE WANT TO SEARCH ANY ELEMENT AND ITS INDEX IN THE 2D ARRAY:-
    public static boolean search(int matrix[][], int key){
        int n = matrix.length;
        int m = matrix[0].length;
        for(int i = 0; i<n; i++){
            for(int j = 0 ; j<m; j++){
                if(matrix[i][j] == key){
                    System.out.println("(The element is found at index: " +i+ ","+j + ")");
                    return true;
                }
            }
        }
        System.out.println("The element is not found");
        return false;
    }
    public static void main(String[] args) {
        int matrix[][] = new int [3][3];
        // HERE WE ARE CREATING A 2D ARRAY OF 3 ROWS AND 3 COLUMNS.
        Scanner sc = new Scanner(System.in);
        //HERE WE CAN ALSO REPRESENT N AND M AS:- int n = 3, m=3;
        int n = matrix.length;
        int m = matrix[0].length;
        // for column we need to use matrix[0].length which shows that we are starting taking input from 0 index of the matrix.
        // THIS REPRESENTS ZEROTH INDEX ROW.
        for(int i = 0; i<n; i++){
            for(int j = 0; j<m; j++){
                matrix[i][j] = sc.nextInt();
            }
        }
        //OUTPUT:-
        for(int i = 0; i<n; i++){
            for(int j = 0; j<m; j++){
                System.out.print(matrix[i][j] + " ");
            }
               System.out.println(" ");
        }
        sc.close();
        search(matrix, 5);
    }
}
