package two_d_arrays;

public class diagonal_sum {
    public static int diagonalSum(int matrix[][]){
        int sum = 0;
        //HERE IN THIS CASE THE CODE IS CORRECT BUT IT IS JUST A BRUTE FORCE CODE MEANS IT IS NOT VERY OPTIMIZED. 
        //HERE THE TIME COMPLEXITY IS O(n^2) WHICH IS VERY BIG TIME COMPLEXITY AND HENCE DOES NOT MAKE OUR CODE A OPTIMIZED ONE.
        // for(int i = 0; i < matrix.length; i++){
        //     for(int j = 0; j<matrix[0].length; j++){
        //         //IN PRIMARY DIAGONAL THE ROWS IS ALWAYS EQUAL TO THE COLUMNS:
        //         if(i == j){
        //             sum += matrix[i][j];
        //         }
        //         //IN SECONDARY DIAGONAL THE SUM OF ROWS AND COLUMNS MUST BE ALWAYS EQUAL TO n-1, WHERE n IS THE NUMBER OF 2-D ARRAY MATRIX.
        //         else if(i+j == matrix.length-1){
        //             sum += matrix[i][j];
        //         }
        //     }
        // }
        //HENCE TO MAKE OR CHANGE OUR CODE TO A OPTIMIZED ONE WITH LESS TIME COMPLEXITY WE WILL USE THIS LINEAR APPROACH.
        //HERE WE WILL USE ONLY ONE FOR LOOP AND WE WILL USE THE INDEX OF THE ARRAY TO FIND THE SUM OF THE DIAGONAL ELEMENTS.

        for(int i = 0; i<matrix.length; i++){
            //FOR PRIMARY DIAGONAL:
            sum += matrix[i][i];
            //FOR SECONDARY DIAGONAL:
            if( i != matrix.length-1-i){
                sum += matrix[i][matrix.length-i-1];
                //HENCE NOW THE BEST TIME COMPLEXITY HAVE BEEN ACHIEVED WHICH IS O(n) WHICH IS THE MOST OPTIMIZED TIME COMPLEXITY.
            }
        }
        return sum;
    }

    public static void main(String[] args) {
        int matrix[][] = {{1, 2, 3, 4},
                          {5, 6, 7, 8},
                          {9, 10, 11, 12},
                          {13, 14, 15, 16}};
    System.out.println(diagonalSum(matrix));
    }
}
