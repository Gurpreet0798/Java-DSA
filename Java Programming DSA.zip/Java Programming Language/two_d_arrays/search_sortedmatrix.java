package two_d_arrays;

public class search_sortedmatrix {
    public static boolean staircaseSearch(int matrix[][], int key){
        int row = 0; int col = matrix[0].length-1;

        while(row < matrix.length && col >= 0){
            //WHEN KEY IS FOUND:
            if(matrix[row][col] == key){
                System.out.print("found key at (" + row + "," + col + ")");
                return true;
            }
            //WHEN KEY IS LESS THAN THE CELL VALUE:
            else if(key < matrix[row][col]){
                col--;
            }

            //WHEN KEY IS GREATER THAN THE CELL VALUE:
            else{
                row++;
            }
        }
        System.out.println("key not found!");
        return false;
    }


    public static void main(String[] args) {
        int matrix[][] = {{10, 20, 30, 40},
                          {15, 25, 35, 45},
                          {27, 29, 37, 48},
                          {32, 33, 39, 50}};
                          int key = 100; 
                          staircaseSearch(matrix, key);    
    }
}
