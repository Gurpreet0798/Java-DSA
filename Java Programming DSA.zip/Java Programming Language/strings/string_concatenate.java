package strings;

public class string_concatenate {
    public static void main(String[] args) {
        String firstName = "Gurpreet";
        String lastName = "Kaur";
        String fullName = firstName + " " + lastName;
        System.out.println("My full name is " + fullName);
    }
}
