package strings;

public class string_charAt {
    public static void printLetters(String str){
        for(int i = 0; i<str.length(); i++){
            System.out.print(str.charAt(i) + " ");
            //PRINT ALL VOWELS OR CONSTANTANTS FROM THE FULL NAME:-
            {
                if(str.charAt(i) == 'a' || str.charAt(i) == 'e' || str.charAt(i) == 'i' || str.charAt(i) == 'o'
                || str.charAt(i) == 'u'){
                    System.out.print(str.charAt(i));
                }
            }
           
        }
    }

    public static void main(String[] args) {
        String firstName = "Gurpreet";
        String lastName = "Kaur";
        String fullName = firstName + " " + lastName;
        // System.out.println(fullName.charAt(7));
        printLetters(fullName);
    }
}
