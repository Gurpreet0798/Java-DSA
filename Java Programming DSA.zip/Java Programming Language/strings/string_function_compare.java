package strings;

public class string_function_compare {
    public static void main(String[] args) {
        String str1 = "Gurpreet";
        String str2 = "Gurpreet";
        String str3 = new String("Gurpreet");
//COMPARING STRINGS 1 AND 2:-
        if(str1 == str2){
            System.out.println("Strings are equal");
        }
        else{
            System.out.println("Strings are not equal");
        }
// //COMPARING STRINGS 1 AND 3:-
//         if(str1 == str3){
//             System.out.println("Strings are equal");
//         }
//         else{
//             System.out.println("Strings are not equal");
//         }
//BUT THE PROBLEM IS THAT STRING 1 AND 2 HAVE ALREADY TAKEN THERE THERE SPACE IN THE MEMORY WHILE STRING 3 IS A NEWLY MADE STRING WHICH IS MADE AGAIN IN THE MEMORY.
//HENCE STRING 1 AND 2 ARE NOT ABLE TO COMPARE THEMSELVES WITH STRING 3.

//FOR THAT THERE IS A IN-BUILT FUNCTION MADE IN JAVA WHICH WILL BE USED FOR SUCH SORT OF COMPARISONS:-
    if(str1.equals(str3)){
        System.out.println("Strings are equal");
    }
    else{
        System.out.println("Strings are not equal");
    }
  }
}
