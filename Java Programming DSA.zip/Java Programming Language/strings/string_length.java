package strings;

public class string_length {
    public static void main(String[] args) {
    String fullName = "Tony Stark";
    System.out.println(fullName.length());
    }
}
