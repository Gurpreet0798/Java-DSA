package strings;
import java.util.*;

public class inputoutput_strings {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        String name = sc.nextLine();
        //THIS STRING CAN ALSO BE WRITTEN AS:
        //String name;
        //name = sc.nextLine;
        System.out.println(name);
        sc.close();
    }
}
