package strings;

public class basic_string {
    public static void main(String[] args) {
        char arr[] = {'a', 'b', 'c', 'd'};
        String str = "abcd";
        String str2 = new String("xyz");

        System.out.println(arr);
        System.out.println(str);
        System.out.println(str2);
    }
}
// HENCE THE STRINGS OF JAVA ARE IMMUTABLE MEANS THE CHANGES CANNOT BE MADE INTO THE PREVIOUS STRING.
// FOR CREATING CHANGES INTO IT MAKE A NEW STRING WITH ALL THE DESIRED CHANGES.