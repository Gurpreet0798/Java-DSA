package strings;

public class stringBuilder_strings {
    public static void main(String[] args) {
        StringBuilder sb = new StringBuilder(" ");
        for(char ch = 'a'; ch<='z'; ch++){
            sb.append(ch);
            //TIME COMPLEXITY FOR THIS CASE WILL BE O(26)
            //WHEN THERE WILL BE N NUMBER OF CHARACTERS WE WANT TO PRINT THEN IN THAT CASE THE TIE COMPLEXITY WILL BE O(n^2).
        }
        System.out.println(sb);
    }
}
