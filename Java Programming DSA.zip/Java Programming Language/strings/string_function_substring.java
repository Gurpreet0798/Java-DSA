package strings;

public class string_function_substring {
    public static String printSubString(String str, int si, int ei){
        String substr = " ";
        for(int i = si; i < ei; i++){
            substr += str.charAt(i);
        }
        return substr;
    }
    public static void main(String[] args) {
        String str = "Hello World";
        //IN-BUILT FUNCTION FOR JAVA SUB-STRING:-
        System.out.println(str.substring(0 , 7));

        // System.out.println(printSubString(str, 0, 7));
    }
}
