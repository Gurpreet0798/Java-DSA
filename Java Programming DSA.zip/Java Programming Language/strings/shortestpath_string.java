package strings;

public class shortestpath_string {
    public static float getShortestPath(String path){
        //HERE WE ARE USING FLOAT INSTEAD OF INT BECAUSE USING UNDER-ROOT IT SOMETIMES RETURNS VALUE IN INT OTHERWISE MOST OF THE TIMES IT RETURNS IN TERMS OF POINT WHICH WILL BE USED WITH THE HELP OF FLOAT:-
        float x = 0;//HERE WE CAN USE x AND y AS A INT TYPE ALSO
        float y = 0;
        for(int i = 0; i < path.length(); i++){
            char dir = path.charAt(i);
            //SOUTH DIRECTION:-
            if(dir == 'S'){
                y--;
            }
            //NORTH DIRECTION:-
            else if(dir == 'N'){
                y++;
            }
            //EAST DIRECTION:-
            else if(dir == 'E'){
                x++;
            }
            //WEST DIRECTION:-
            else{
                x--;
            }
        }
        float X2 = x*x;//x^2
        //WITH THAT I HAVE TO CHANGE HERE ALSO TO INT IF I AM CHANGING ON TOP TO CONVERT IT INTO FLOAT.
        float Y2 = y*y;//y^2
        return (float)Math.sqrt(X2 + Y2);
    }

    public static void main(String[] args) {
        String path = "WNEENESENNN";
        System.out.println(getShortestPath(path));
    }
}
