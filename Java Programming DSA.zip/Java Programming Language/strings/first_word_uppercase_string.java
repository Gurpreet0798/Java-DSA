package strings;

public class first_word_uppercase_string {
    public static String toUpperCase(String str){
        StringBuilder sb = new StringBuilder(" ");
//CHARACTER ON 0TH INDEX IS BEING CONVERTED INTO UPPERCASE:-
        char ch = Character.toUpperCase(str.charAt(0));
        sb.append(ch);
//NOW WE WILL BE APPENDING THE REST OF THE CHARACTERS IN THE STRING:-
        for(int i = 1; i<str.length(); i++){
            if(str.charAt(i) == ' ' && i<str.length()-1){
                sb.append(str.charAt(i));
                i++;
                sb.append(Character.toUpperCase(str.charAt(i)));
            }
            else{
                sb.append(str.charAt(i));
            }
        }
        return sb.toString();
    }
    public static void main(String[] args) {
        String str = "hi, i am gurpreet";
        System.out.println(toUpperCase(str));
    }
}
