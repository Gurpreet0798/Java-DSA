import java.util.*;
public class calculator {
    public static void main(String args[]){
        Scanner sc = new Scanner(System.in);
        int a = sc.nextInt();
        int b = sc.nextInt();
        char operator = sc.next().charAt(0);// FOR INPUT OF OPERATOR IN THE JAVA PROGRAM.
        sc.close();
        System.out.println("Enter 1st number: " +a);   
        System.out.println("Enter 2nd number: " +b); 
        System.out.println("Enter operator: " +operator); 
        switch(operator){
            case '+':
            System.out.println("Addition: " +(a+b));
            break;
            case '-':
            System.out.println("Subtraction: " +(a-b));
            break;
            case '*':
            System.out.println("Multiplication: " +(a*b));
            break;
            case '/':
            System.out.println("Division: " +(a/b));
            break;
            case '%':
            System.out.println("Modulus: " +(a%b));
            default:
            System.out.println("Invalid input");
        }
     }
    
}
