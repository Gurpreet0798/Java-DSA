public class passfail {
    public static void main(String args[]){
        int marks = 30;
        String result = (marks>=33)?"pass":"fail";
        System.out.println(result);
    }
    
}
