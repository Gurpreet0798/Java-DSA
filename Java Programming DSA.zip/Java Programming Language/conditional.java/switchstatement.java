public class switchstatement {
    public static void main(String args[]){
         int number = 1;
         switch(number){
            case 1: System.out.println("Samosa");
                    break;
            case 2: System.out.println("Burger");
                    break;
            case 3: System.out.println("Pizza");
                    break;
            default: System.out.println("Stop Eating");
         }
    }
}
// IT CAN ALSO BE USED IN CASE OF CHARACTERS AND STRINGS
//IN CASE OF CHARACTERS: JUST WRITE ALPHABET AND IN THE CASES WRITE THE ALPHABETS INSTEAD OF NUMBERS.
