public class evenodd {
    public static void main(String args[]){
        int n = 18;
        if(n%2==0){
            System.out.println("Even: " +n);
        }
        else{
            System.out.println("Odd: " +n);
        }
    }
    
}
