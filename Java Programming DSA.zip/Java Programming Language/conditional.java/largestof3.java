public class largestof3 {
    public static void main(String args[]){
        int A= 1;
        int B= 3;
        int C= 2;
        if(A>B && A>C){
            System.out.println("A is the largest number: " +A);
        }
        else if(B>A && B>C){
            System.out.println("B is the largest number: " +B);
        }
        else{
            System.out.println("C is the largest number: " +C);
        }
    }

    
}
