//question 1....
// import java.util.*;

// public class practise {
//     public static void main(String args[]){
//         Scanner sc = new Scanner(System.in);
//         int n = sc.nextInt();
//         if(n>0){
//             System.out.println("Positive");
//         }
//         else{
//             System.out.println("Negative");
//         }
//         sc.close();
//     }
// }


//question 2....
// public class practise {
//     public static void main(String args[]){
//         double temp = 103.5;
//         if(temp>100){
//             System.out.println("Fever");
//         }
//         else{
//             System.out.println("Normal");
//         }
//     }
// }


//question 3....
// import java.util.*;
// public class practise{
//     public static void main(String args[]){
//         Scanner sc = new Scanner(System.in);
//         int week = sc.nextInt();
//         System.out.println("Enter the week number: " +week);
//         sc.close();
//         switch(week){
//             case 1:
//             System.out.println("Monday");
//             break;
//             case 2:
//             System.out.println("Tuesday");
//             break;
//             case 3:
//             System.out.println("Wednesday");
//             break;
//             case 4:
//             System.out.println("Thursday");
//             break;
//             case 5:
//             System.out.println("Friday");
//             break;
//             case 6:
//             System.out.println("Saturday");
//             break;
//             case 7:
//             System.out.println("Sunday");
//             break;
//             default:
//             System.out.println("Invalid input");
//         }
//     }
// }


//question 4....
// IN TERMS OF BOOLEAN IT WILL BE FALSE WHILE IN TERMS OF INTEGER IT WILL BE a.
// X = FALSE
// Y = 63.


//question 5....
import java.util.*;
public class practise{
    public static void main(String args[]){
        Scanner sc = new Scanner(System.in);
        System.out.println("Enter the year: ");
        int year = sc.nextInt();
        sc.close();
        //TO CHECK WHETHER IT IS A LEAP YEAR OR NOT.
        if(year % 4 == 0 && year % 100 != 0 || year % 400 == 0){
            System.out.println("Leap year");
        }
        else{
            System.out.println("Not a leap year");
        }
   
   
    }
}
