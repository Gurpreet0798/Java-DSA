public class elseif {
    public static void main(String args[]){

        int age = 25;
        if(age>=18){
            System.out.println("AGE = Adult" +age);
        }
        else if(age>16){
            System.out.println("Teenager");
        }
        else{
            System.out.println("Child");
        }
        
    }
}
