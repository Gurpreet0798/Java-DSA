public class largestof2 {
    public static void main(String args[]){
        int a = 10;
        int b = 30;
        if(a>b){
            System.out.println("a is greater than b: " +a);
        }
        else{
            System.out.println("b is greater than a: " +b);
        
        }
    }
    
}
