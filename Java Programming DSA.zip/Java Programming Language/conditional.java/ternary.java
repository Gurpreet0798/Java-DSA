public class ternary {
    public static void main(String args[]){
       int number = 9;
         String type = (number%2==0)?"even number":"odd number";
            System.out.println(type);
    }
}
