import java.util.*;
public class incometax {
    public static void main(String args[]){
      
        Scanner sc = new Scanner(System.in);
        int income = sc.nextInt();
        System.out.println("Enter your income: " +income);
        sc.close();
        if(income < 500000){
            float tax = income*0.01f;
            System.out.println("Tax paid by you is: " +tax);
        }
        else if(income<=500000 && income>1000000){
            float tax = income*0.2f;
            System.out.println("Tax paid by you is: " +tax);
        }
        else{
            float tax = income*0.3f;
            System.out.println("Tax paid by you is: " +tax);
        }

    }
    
}
