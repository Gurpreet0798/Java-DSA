public class question1 {
    public static void main(String[] args) {
        int ground = 20;
        int track = 19;
        double areag = 3.14*ground*ground;
        double areat = 3.14*track*track;
        double area = areag - areat;
        System.out.println("The area of the ring is: " +area);
        double sqm = 500;
       System.out.println("The cost of fencing the ring is: " +sqm*area);
    }
}
