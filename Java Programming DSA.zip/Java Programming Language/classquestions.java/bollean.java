public class bollean {
    public static void main(String[] args) {
        
    }
}
