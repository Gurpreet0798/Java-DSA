// import java.util.*;
// public class question2 {
//     public static void main(String[] args) {
//         Scanner sc = new Scanner(System.in);
//         System.out.println("Enter the customer ID: ");
//         int id = sc.nextInt();
//         System.out.println("Enter the units consumed: ");
//         int units = sc.nextInt();
//         if(units<=25){
//             int result = 5*units;
//             System.out.println("The total bill is: " +result);
//         }
//         // if(u)
//     }
// }
