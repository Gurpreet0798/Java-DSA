import java.util.*;
public class repeater {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        int num = sc.nextInt();
        for(int i = 0; i <= num; i++){
            if(i==num){
                System.out.print(num);
            }
        }
        sc.close();
    }
}
