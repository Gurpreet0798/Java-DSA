import java.util.*;
public class question3 {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        int decimal = sc.nextInt();
        System.out.println("Enter the decimal number: " +decimal);
        //FOR A DECIMAL NUMBER:-
        for(int i = 0; i<=decimal; i++){
            int num = decimal/2;
            System.out.println(num);
            // System.out.println(num);
            // System.out.println(num);
            // System.out.println(num);
        }
        // int num = decimal/2;
        sc.close();
    }
}
