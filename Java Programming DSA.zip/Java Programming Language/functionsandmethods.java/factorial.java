public class factorial {
    public static int Factorial(int n){
        int f = 1;
        for(int i = 1; i<=n; i++){// PRACTISE BY DRY RUNNING.
            f = f*i;
        }
        return f;//FACTORIAL.
    }
    public static void main(String[] args) {
        int n = 4;
        int fact = Factorial(n);
        System.out.println(fact);
        //CAN ALSO BE CALLED AS:-
        System.out.println(Factorial(7));
    }
}
