public class blockscope {
//     public static void main(String[] args) {
//         int a = 10;
//         {
//             int b = 20;
//             System.out.println(b);
//             System.out.println(a);
//         }
//         // System.out.println(b); //error AS b IS DECLARED IN BLOCK SCOPE. SO WE WILL NOT BE ABLE TO USE IT IN main() METHOD.
//         // System.out.println(b);//ERROR AS DESCRIBED ABOVE AS IT IS CALLED AFTER THE BLOCK SCOPE.
//     }
// }

//WE CAN USE A METHOD OF FOR LOOP ALSO FOR HAVING A BETTER UNDERSTANDING OF BLOCK SCOPE.
public static void main(String[] args) {
    for(int i = 0; i<=5; i++){
        // System.out.println(i);
    }
    //  System.out.println(i);HERE IT WILL SHOW ERROR AS i IS DECLARED IN FOR LOOP SCOPE. SO WE WILL NOT BE ABLE TO USE IT IN main() METHOD.
    int i = 4;
    System.out.println(i);//HERE IT WILL NOT SHOW ERROR AS i IS DECLARED IN main() METHOD. SO WE WILL BE ABLE TO USE IT IN main() METHOD.
}
}