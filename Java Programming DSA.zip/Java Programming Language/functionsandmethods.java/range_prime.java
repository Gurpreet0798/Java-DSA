public class range_prime {
    public static void primesinrange(int n){
        for(int i = 2; i<=n; i++){
            if(isprime(i)){
                System.out.println(i); 
            }
        }
    }
    public static boolean isprime(int n){
        boolean isprime = true;// by removing this line, the code will work with the return statement false and true.
        for(int i = 2; i<=n-1; i++){
            if(n%i==0){
                isprime = false;
                break;
                //return false;
            }
        }
        return isprime;
        //return true; 
    }
    public static void main(String[] args) {
        primesinrange(10);
    }
}
