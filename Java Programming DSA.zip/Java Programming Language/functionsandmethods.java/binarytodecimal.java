public class binarytodecimal {
    public static void binTodec(int binNum){
        int pow = 0;
        int decNum = 0;
        while(binNum > 0){
            int lastDigit = binNum%10;//FOR LAST DIGIT.
            decNum = decNum + lastDigit*(int)Math.pow(2,pow);//typecasting is done because Math.pow returns double value.
            pow++;
             binNum = binNum/10;//FOR REMOVING LAST DIGIT AND OBTAINING THE REMAINING NUMBER.
        }
        System.out.println(decNum);
    }
    public static void main(String[] args) {
        binTodec(101);
    }
}
