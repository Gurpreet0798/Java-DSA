public class examplefunction {
    public static void printHelloWorld(){
        System.out.println("Hello World");
        System.out.println("Hello World");
        System.out.println("Hello World");
        return; // This is optional. If you don't write this, the function will still work.
        //BUT IN THIS CASE THE RETURN TYPE IS VOID SO WE DON'T NEED TO WRITE RETURN STATEMENT.
        // HOWEVER IF THE RETURN TYPE IS INT THEN WE NEED TO WRITE RETURN STATEMENT BY DEFINING THE VALUE OF THE RETURN TYPE.
    }
    public static void main(String args[]){
        printHelloWorld(); // Calling the function. HERE THE FUNCTION IS CALLED WHICH IS DEFINED AT THE TOP IN PUBLIC STATIC VOID COLUMN...
    }
}
