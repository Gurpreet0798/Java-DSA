public class methodscope {
    public static void printS(){
        // int s = 45;
    }
    public static void main(String[] args) {
        // System.out.println(s); //error AS S IS DECLARED IN printS() METHOD. SO WE WILL NOT BE ABLE TO USE IT IN main() METHOD.
    }
}
