public class callbyvalue {
    public static void swap(int a, int b){
        int temp = a;
        a = b;
        b = temp;
        System.out.println("The value of a is: " +a);
        System.out.println("The value of b is: " +b);
    }
//IN JAVA CALL BY VALUE IS ALWAYS APPLIED. WE CANNOT CHANGE THE VALUE OF A AND B IN THE MAIN FUNCTION.
    public static void main(String[] args) {
        int a = 5;
        int b = 10;
        swap(a, b);//WE NEED TO MENTION THE VALUES OF A AND B IN THE BRACKET BECAUSE WE ARE CALLING THE VALUES OF A AND B IN THE FUNCTION AS WHEN THE CODE WILL RUN HOW WILL IT KNOW THAT WHICH FUNCTION MUST BE CALLED BY IT.
    }
}
