public class primeno {
    public static boolean isprime(int n){
        boolean isprime = true;// by removing this line, the code will work with the return statement false and true.
        for(int i = 2; i<=n-1; i++){
            if(n%i==0){
                isprime = false;
                break;
                //return false;
            }
        }
        return isprime;
        //return true; 
    }
    public static void main(String[] args) {
        System.out.println(isprime(18));
    }
}
//USE CORNER CASES ALSO FOR BETTER UNDERSTANDING AND SOLVING HE QUESTION COMPLETELY.