import java.util.*;
public class syntaxwithparameters {
    public static int calculatesum(int a, int b){//WHILE HERE IT IS CALLED PARAMETERS OR FORMAL PARAMETERS.
        //HERE WE ARE TAKING THE VALUES OF A AND B IN THE FUNCTION AND THEN WE ARE RETURNING THE VALUE OF SUM AND TAKING THIS INT A AND INT B IN THE BRACKET IS CALLED PARAMETERS.
        //ALSO CHANGE THE VOID TO INT BECAUSE WE ARE RETURNING THE VALUE OF SUM.
        int sum = a+b;
        //HERE WE ARE NOT TAKING THE VALUES OF A AND B BECAUSE WE HAVE ALREADY TAKEN THE VALUES OF A AND B IN THE MAIN FUNCTION.
       // System.out.println("Sum is: " +sum);
        //IF YOU ARE CHANGING VOID TO INT FUNCTION THEM PRINT THE SYSOUT STATEMENT IN THE MAIN FUNCTION.
       return sum;
       // HERE IT IS IMPORTANT TO WRITE RETURN STATEMENT BECAUSE WE ARE RETURNING THE VALUE OF SUM.
    }
    public static void main(String args[]){
        Scanner sc = new Scanner(System.in);
        int a = sc.nextInt();
        int b = sc.nextInt();
        int sum =  calculatesum(a,b);// HERE CALLING THE VALUE FROM THE FUNCTION IS CALLED THE ARGUMENTS OR ACTUAL PARAMETERS.
        // HERE BOTH THE VALUES OF A AND B ARE TAKEN IN THE MAIN FUNCTION.
        // BOTH THE INT IN BOTH THE FUNCTIONS ARE DIFFERENT.
        sc.close();
        System.out.println("Sum is: " +sum);
    }
}
 